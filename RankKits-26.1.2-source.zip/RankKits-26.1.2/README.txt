RankKits — Minecraft Java Edition 26.1.2 / Fabric

CURRENT PROTOTYPE
- /rankkits lists the available rank kit names.
- /kit <rank> gives the starter kit for that rank.
- Crystal_PvPer gets extra totems, ender pearls and obsidian.

IMPORTANT LIMITATIONS
- This is source code, not a tested compiled mod JAR.
- Rank ownership/permissions, a chest GUI, ban tools, and Imperator weather/time controls are not implemented yet.
- Every player can currently use any kit command. Do not use this on a public server as an admin/rank system.

BUILD REQUIREMENTS
- Java/JDK 25
- Gradle 9.4 or a compatible Gradle installation
- Internet access to download Minecraft/Fabric dependencies

Build command from this folder:
  gradle build

The built mod should appear under build/libs/ as rankkits-1.0.0.jar.

Install the compiled JAR into the Minecraft instance's mods folder. The instance must use Fabric for Minecraft 26.1.2 and have a matching Fabric API installed.
