package uz.rankkits;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class RankKitsMod implements ModInitializer {
    private static final Set<String> RANKS = Set.of(
            "owner", "admin", "imperator", "elita", "moderator",
            "helper", "ritsar", "general", "crystal_pvper"
    );

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(Commands.literal("rankkits")
                    .executes(context -> {
                        context.getSource().sendSuccess(() -> Component.literal(
                                "RankKits ranks: Owner, Admin, Imperator, Elita, Moderator, Helper, Ritsar, General, Crystal_PvPer. Use /kit <rank>."), false);
                        return 1;
                    }));

            dispatcher.register(Commands.literal("kit")
                    .then(Commands.argument("rank", StringArgumentType.word())
                            .suggests((context, builder) -> {
                                RANKS.forEach(builder::suggest);
                                return builder.buildFuture();
                            })
                            .executes(context -> {
                                ServerPlayer player = context.getSource().getPlayerOrException();
                                String rank = StringArgumentType.getString(context, "rank").toLowerCase(Locale.ROOT);
                                if (!RANKS.contains(rank)) {
                                    context.getSource().sendFailure(Component.literal("Unknown rank. Use /rankkits to see available kits."));
                                    return 0;
                                }
                                giveKit(player, rank);
                                context.getSource().sendSuccess(() -> Component.literal("RankKits: " + rank + " kit given!"), false);
                                return 1;
                            })));
        });
    }

    private static void giveKit(ServerPlayer player, String rank) {
        // Starter version: practical survival supplies and armor; no rank permissions are stored yet.
        add(player, new ItemStack(Items.COOKED_BEEF, 32));
        add(player, new ItemStack(Items.GOLDEN_APPLE, rank.equals("owner") || rank.equals("admin") ? 16 : 8));
        add(player, new ItemStack(Items.TOTEM_OF_UNDYING, rank.equals("crystal_pvper") ? 16 : 2));
        add(player, new ItemStack(Items.ENDER_PEARL, rank.equals("crystal_pvper") ? 32 : 8));
        add(player, new ItemStack(Items.OBSIDIAN, rank.equals("crystal_pvper") ? 64 : 16));
        add(player, new ItemStack(Items.EXPERIENCE_BOTTLE, rank.equals("owner") ? 64 : 16));
        add(player, new ItemStack(Items.DIAMOND_PICKAXE, 1));
        add(player, new ItemStack(Items.SHIELD, 1));
        add(player, new ItemStack(Items.DIAMOND_CHESTPLATE, 1));
        add(player, new ItemStack(Items.DIAMOND_LEGGINGS, 1));
        add(player, new ItemStack(Items.DIAMOND_BOOTS, 1));
        add(player, new ItemStack(Items.DIAMOND_HELMET, 1));
    }

    private static void add(ServerPlayer player, ItemStack stack) {
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
    }
}
